package com.example.proxy;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Entity.Purchase;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("customer-service")
public interface PurchaseServiceProxy {
	
	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodCustomerOrders")
	@GetMapping("/purchase/byEmail/{email}")
	public List<Purchase> customerOrders(@PathVariable String email);
	
	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodGetAllPurchase")
	@GetMapping("/purchase")
	public List<Purchase> getAllPurchase();

	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodDeletePurchase")
	@DeleteMapping("/purchase/{id}")
	public ResponseEntity<Map<String, Boolean>> deletePurchase(@PathVariable Long id);

	// Fallback methods
	default List<Purchase> fallbackMethodCustomerOrders(String email, Throwable cause) {
		System.out.println("Exception raised with message: ====>" + cause.getMessage());
		return Collections.emptyList();
	}

	default List<Purchase> fallbackMethodGetAllPurchase(Throwable cause) {
		System.out.println("Exception raised with message: ====>" + cause.getMessage());
		return Collections.emptyList();
	}

	default ResponseEntity<Map<String, Boolean>> fallbackMethodDeletePurchase(Long id, Throwable cause) {
		System.out.println("Exception raised with message: ====>" + cause.getMessage());
		Map<String, Boolean> response = new HashMap<>();
		response.put("success", false);
		return ResponseEntity.ok(response);
	}
}
