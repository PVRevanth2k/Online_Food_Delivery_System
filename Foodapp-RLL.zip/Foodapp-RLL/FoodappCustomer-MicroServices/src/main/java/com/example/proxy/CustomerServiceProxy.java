package com.example.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Customer;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("customer-service")
public interface CustomerServiceProxy {
	
	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodGetAllCustomers")
	@GetMapping("/customers")
	public List<Customer> getAllCustomers();
	
	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodSearchCustomer")
	@GetMapping("/customers/search/{keyword}")
	public List<Customer> searchCustomer(@PathVariable String keyword);
	
	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodGetCustomer")
	@GetMapping("/customers/{cust_email}")
	public Customer getCustomer(@PathVariable String cust_email);
	
	@Retry(name = "customer-service")
	@CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodUpdateCustomer")
	@PutMapping("/customers/{email}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable String email, @RequestBody Customer coustomerDetails);

	// Fallback methods
    default List<Customer> fallbackMethodGetAllCustomers(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new ArrayList<>();
    }

    default List<Customer> fallbackMethodSearchCustomer(String keyword, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new ArrayList<>();
    }

    default Customer fallbackMethodGetCustomer(String cust_email, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new Customer();
    }

    default ResponseEntity<Customer> fallbackMethodUpdateCustomer(String email, Customer customerDetails, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Customer());
    }
}
