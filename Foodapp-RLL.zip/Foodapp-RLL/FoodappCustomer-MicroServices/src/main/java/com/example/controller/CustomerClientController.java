package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Customer;
import com.example.proxy.CustomerServiceProxy;


@RestController
@Scope("request")
public class CustomerClientController {
	

	@Autowired
	private CustomerServiceProxy customerServiceProxy;
	
	@GetMapping("/customers")
	public List<Customer> getAllCustomers(){
		List<Customer> customer = customerServiceProxy.getAllCustomers();
		return  customer;
	}

	@GetMapping("/customers/search/{keyword}")
	public List<Customer> searchCustomer(@PathVariable String keyword){
		List<Customer> customer = customerServiceProxy.searchCustomer(keyword);
		return  customer;

	}
	
	@GetMapping("/customers/{cust_email}")
	public Customer getCustomer(@PathVariable String cust_email) {
		Customer customer = customerServiceProxy.getCustomer(cust_email);
		return customer;

	}
	
	@PutMapping("/customers/{email}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable String email, @RequestBody Customer coustomerDetails){
		return customerServiceProxy.updateCustomer(email, coustomerDetails);
	}
	
}
