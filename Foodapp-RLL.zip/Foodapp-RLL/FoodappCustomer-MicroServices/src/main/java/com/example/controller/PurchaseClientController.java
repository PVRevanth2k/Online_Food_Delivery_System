package com.example.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Purchase;
import com.example.proxy.PurchaseServiceProxy;

@RestController
@Scope("request")
public class PurchaseClientController {

	@Autowired
	private PurchaseServiceProxy purchaseServiceProxy;
	
	@GetMapping("/purchase/byEmail/{email}")
	public List<Purchase> customerOrders(@PathVariable String email){
		List<Purchase> purchase = purchaseServiceProxy.customerOrders(email);
		return purchase;
	}
	
	@GetMapping("/purchase")
	public List<Purchase> getAllPurchase(){
		List<Purchase> purchase = purchaseServiceProxy.getAllPurchase();
		return purchase;
	}
	
	@DeleteMapping("/purchase/{id}")
	public ResponseEntity<Map<String, Boolean>> deletePurchase(@PathVariable Long id){
		return purchaseServiceProxy.deletePurchase(id);
	}
}
