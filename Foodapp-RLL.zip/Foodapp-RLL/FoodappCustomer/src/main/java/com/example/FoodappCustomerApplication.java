package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.example.entity.Customer;
import com.example.entity.Purchase;
import com.example.repository.CustomerRepository;
import com.example.repository.PurchaseRepository;


@SpringBootApplication
@EnableDiscoveryClient
public class FoodappCustomerApplication implements CommandLineRunner{
	
	@Autowired
	@Qualifier("customerRepository")
	private CustomerRepository customerRepository;
	
	@Autowired
	@Qualifier("purchaseRepository")
	private PurchaseRepository purchaseRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(FoodappCustomerApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
	
		//Customer1
		Customer cust1 = new Customer();
		cust1.setEmail("cust1@gmail.com");
		cust1.setPassword("cust1");
		cust1.setName("Customer One");
		cust1.setContact("9876543210");
		cust1.setAddress("TamilNadu");
		customerRepository.save(cust1);
		
		//Customer2
		Customer cust2 = new Customer();
		cust2.setEmail("cust2@gmail.com");
		cust2.setPassword("cust2");
		cust2.setName("Customer Two");
		cust2.setContact("9876543220");
		cust2.setAddress("Kerala");
		customerRepository.save(cust2);
		
		//Purchase1
		Purchase purchase1 = new Purchase();
		purchase1.setProductname("Almond and Date Cake");
		purchase1.setQuantity(3);
		purchase1.setCustomer(cust2);
		java.sql.Date date1 = new java.sql.Date(new java.util.Date().getTime());
		purchase1.setDop(date1);
		purchase1.setTransactionid("123AB56789");
		purchase1.setTotalcost(150*purchase1.getQuantity());
		purchaseRepository.save(purchase1);
		
		//Purchase2
		Purchase purchase2 = new Purchase();
		purchase2.setProductname("Chicken Sandwich");
		purchase2.setQuantity(2);
		purchase2.setCustomer(cust1);
		java.sql.Date date2 = new java.sql.Date(new java.util.Date().getTime());
		purchase2.setDop(date2);
		purchase2.setTransactionid("123AB9LM89");
		purchase2.setTotalcost(160*purchase2.getQuantity());
		purchaseRepository.save(purchase2);
		

	
	}

}