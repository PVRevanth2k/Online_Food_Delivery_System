package com.example.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Entity.Cart;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("admin-service")
public interface CartServiceProxy {
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodFindAll")
	@GetMapping("/carts")
	public List<Cart> findAll();
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodDeleteCart")
	@DeleteMapping("/carts/{id}")
	public ResponseEntity<?> deleteCart(@PathVariable("id") Long id);
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodDeleteAllCart")
	@DeleteMapping("/carts")
	public void deleteAllCart();
	
	// Fallback methods
    default List<Cart> fallbackMethodFindAll(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new ArrayList<>();
    }

    default ResponseEntity<?> fallbackMethodDeleteCart(Long id, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Delete failed");
    }

    default void fallbackMethodDeleteAllCart(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
    }

}
