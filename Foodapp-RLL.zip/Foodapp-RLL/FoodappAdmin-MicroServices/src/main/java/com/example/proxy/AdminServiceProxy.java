package com.example.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Admin;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("admin-service")
public interface AdminServiceProxy {
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetAdmin")
	@GetMapping("/admin")
	public List<Admin> getAdmin();
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetAdminByUsername")
	@GetMapping("/admin/{username}")
	public List<Admin> getAdminByusername(@PathVariable("username") String username);
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodAddAdmin")
	@PostMapping("/admin")
	public void addAdmin(@RequestBody Admin admin);
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodUpdateAdmin")
	@PutMapping("/admin")
	public void updateAdmin(@RequestBody Admin admin);
	
	// Fallback methods
    default List<Admin> fallbackMethodGetAdmin(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new ArrayList<>();
    }

    default List<Admin> fallbackMethodGetAdminByUsername(String username, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new ArrayList<>();
    }

    default void fallbackMethodAddAdmin(Admin admin, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
    }

    default void fallbackMethodUpdateAdmin(Admin admin, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
    }
}
