package com.example.proxy;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Product;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("admin-service")
public interface ProductServiceProxy {
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetAdminProducts")
	@GetMapping("/products/Admin")
	public List<Product> getAdminProducts();
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "food-service", fallbackMethod = "fallbackMethodGetAllProducts")
	@GetMapping("/products/cust")
	public List<Product> getAllProducts();
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetProductById")
	@GetMapping("products/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable long id);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodAddProduct")
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodUpdateProduct")
	@PutMapping("/products/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetSearchProducts")
	@GetMapping("products/search/{keyword}")
	public List<Product> getSearchProducts(@PathVariable String keyword);
	
	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetVeg")
	@GetMapping("products/Veg")
	public List<Product> getVeg();

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetNonVeg")
	@GetMapping("products/NonVeg")
	public List<Product> getNonVeg();

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodGetDessert")
	@GetMapping("products/Dessert")
	public List<Product> getDessert();

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodDeleteProduct")
	@DeleteMapping("/products/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id);

	
	// Fallback methods
    default List<Product> fallbackMethodGetAdminProducts(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList();
    }

    default List<Product> fallbackMethodGetAllProducts(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList();
    }

    default ResponseEntity<Product> fallbackMethodGetProductById(long id, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return ResponseEntity.ok(new Product());
    }
    
    default Product fallbackMethodAddProduct(Product product, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return new Product();
    }

    default ResponseEntity<Product> fallbackMethodUpdateProduct(Long id, Product productDetails, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Product());
    }

    default List<Product> fallbackMethodGetSearchProducts(String keyword, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList();
    }

    default List<Product> fallbackMethodGetVeg(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList();
    }

    default List<Product> fallbackMethodGetNonVeg(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList();
    }

    default List<Product> fallbackMethodGetDessert(Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        return Collections.emptyList();
    }

    default ResponseEntity<Map<String, Boolean>> fallbackMethodDeleteProduct(Long id, Throwable cause) {
        System.out.println("Exception raised with message: ====>" + cause.getMessage());
        Map<String, Boolean> response = new HashMap<>();
        response.put("success", false);
        return ResponseEntity.ok(response);
    }
}
