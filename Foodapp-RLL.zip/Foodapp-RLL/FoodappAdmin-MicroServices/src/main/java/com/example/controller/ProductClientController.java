package com.example.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Product;
import com.example.proxy.ProductServiceProxy;

@RestController
@Scope("request")
public class ProductClientController {
	
	@Autowired
	private ProductServiceProxy productServiceProxy;
	
	@GetMapping("/products/Admin")
	public List<Product> getAdminProducts(){
		List<Product> product = productServiceProxy.getAdminProducts();
		return product;
	}

	@GetMapping("/products/cust")
	public List<Product> getAllProducts(){
		List<Product> product = productServiceProxy.getAllProducts();
		return product;
	}
	
	@GetMapping("products/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable long id){
		ResponseEntity<Product> product = productServiceProxy.getProductById(id);
		return product;
	}
	
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product) {
		return productServiceProxy.addProduct(product);
	}

	@PutMapping("/products/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails){
		return productServiceProxy.updateProduct(id, productDetails);
	}

	@GetMapping("products/search/{keyword}")
	public List<Product> getSearchProducts(@PathVariable String keyword){
		List<Product> product = productServiceProxy.getSearchProducts(keyword);
		return product;
	}

	@GetMapping("products/Veg")
	public List<Product> getVeg(){
		List<Product> product = productServiceProxy.getVeg();
		return product;
	}

	@GetMapping("products/NonVeg")
	public List<Product> getNonVeg(){
		List<Product> product = productServiceProxy.getNonVeg();
		return product;
	}

	@GetMapping("products/Dessert")
	public List<Product> getDessert(){
		List<Product> product = productServiceProxy.getDessert();
		return product;
	}

	@DeleteMapping("/products/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id){
		return productServiceProxy.deleteProduct(id);
	}

}
