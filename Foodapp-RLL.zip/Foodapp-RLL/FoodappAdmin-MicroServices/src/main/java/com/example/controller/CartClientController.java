package com.example.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Cart;
import com.example.proxy.CartServiceProxy;


@RestController
@Scope("request")
public class CartClientController {
	
	@Autowired
	private CartServiceProxy cartServiceProxy;
	
	@GetMapping("/carts")
	public List<Cart> getAdmin() {
		
		List<Cart> cart = cartServiceProxy.findAll();
		return cart;
	}
	
	@DeleteMapping("/carts/{id}")
	public ResponseEntity<?> deleteCart(@PathVariable("id") Long id){
		return cartServiceProxy.deleteCart(id);
	}
	
	@DeleteMapping("/carts")
	public void deleteAllCart() {
		cartServiceProxy.deleteAllCart();
	}
}
