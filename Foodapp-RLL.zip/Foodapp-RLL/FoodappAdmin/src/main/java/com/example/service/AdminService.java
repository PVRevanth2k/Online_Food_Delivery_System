package com.example.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.example.repository.AdminRepository;

@Service
public class AdminService {
	
	private final AdminRepository adminRepository;

	@Autowired
	public AdminService(AdminRepository adminRepository) {
		this.adminRepository = adminRepository;
	}

	public void addAdmin(Admin admin) {
		adminRepository.save(admin);
	}

	public void updateAdmin(Admin admin) {
		adminRepository.save(admin);
	}

	public List<Admin> getAdminByUsername(String username) {
		return adminRepository.findByusername(username);
	}
	
	public List<Admin> getAdmin() {
		return adminRepository.findAll();
	}

}
