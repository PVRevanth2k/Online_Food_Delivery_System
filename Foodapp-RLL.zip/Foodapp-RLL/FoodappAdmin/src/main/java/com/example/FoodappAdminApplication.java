package com.example;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.example.entity.Admin;
import com.example.entity.Cart;
import com.example.entity.Product;
import com.example.repository.AdminRepository;
import com.example.repository.CartRepository;
import com.example.repository.ProductRepository;

@SpringBootApplication
@EnableDiscoveryClient
public class FoodappAdminApplication implements CommandLineRunner{
	
	@Autowired
	@Qualifier("adminRepository")
	private AdminRepository adminRepository;
	
	@Autowired
	@Qualifier("productRepository")
	private ProductRepository productRepository;
	
	@Autowired
	@Qualifier("cartRepository")
	private CartRepository cartRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(FoodappAdminApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
	
		//Admin
		Admin admin = new Admin();
		admin.setUsername("admin");
		admin.setPassword("Admin123");
		adminRepository.save(admin);

		//Product1
		Product pro1 = new Product();
		pro1.setName("Panneer Sandwich");
		pro1.setAvail("yes");
		pro1.setPrice(150);
		pro1.setCategory("Veg");
		pro1.setDesc("Delicious");
		productRepository.save(pro1);
		
		//Product2
		Product pro2 = new Product();
		pro2.setName("Chicken Sandwich");
		pro2.setAvail("yes");
		pro2.setPrice(160);
		pro2.setCategory("NonVeg");
		pro2.setDesc("Spicy");
		productRepository.save(pro2);

		//Product3
		Product pro3 = new Product();
		pro3.setName("Cheese Corn Sandwich");
		pro3.setAvail("no");
		pro3.setPrice(140);
		pro3.setCategory("Veg");
		pro3.setDesc("Delicious");
		productRepository.save(pro3);

		//Product4
		Product pro4 = new Product();
		pro4.setName("Almond and Date Cake");
		pro4.setAvail("yes");
		pro4.setPrice(150);
		pro4.setCategory("Dessert");
		pro4.setDesc("Tasty");
		productRepository.save(pro4);
		
		//Cart1
		Cart cart1 = new Cart();
		cart1.setQuantity(2);
		cart1.setProduct(pro1);
		cart1.setPrice(pro1.getPrice()*cart1.getQuantity());
		cartRepository.save(cart1);
		
		//Cart2
		Cart cart2 = new Cart();
		cart2.setQuantity(1);
		cart2.setProduct(pro3);
		cart2.setPrice(pro3.getPrice()*cart2.getQuantity());
		cartRepository.save(cart2);
	}

}